<!DOCTYPE HTML>
<html>
        <head><title>insta feed</title></head>
<body>
    <div id="instafeed">

    </div>
    <script src="./js/instafeed.min.js"></script>
    <script src="./js/custom.js"></script>

</body>
</html>