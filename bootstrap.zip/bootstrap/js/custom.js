$(document).ready(function() {


  var userFeed = new Instafeed({
      get: 'user',
      userId: '7450085626',
      limit: '4',
      resolution: 'standard_resolution',
      accessToken: '7450085626.1677ed0.808bff9f2e4f4afa892eaf18ab2f4ab0',
      sortBy: 'most-recent',
      template: '<div class="col-xs-6 col-sm-6 col-md-3" ><a href="{{image}}"><div class="img-featured-container" style="width:100%;padding:0px;"><img src="{{image}}" class="img-responsive2"></div></a><div class="like_comment" syle="position:abso;"><span style="padding-right:20px;" class="likes"><i class="fa fa-heart" aria-hidden="true"></i>{{likes}}</span><spanstyle="padding-left:20px;" class="comments"><i class="fa fa-comments"aria-hidden="true"></i> {{comments}}</span></div></div>',
  });
      userFeed.run();

});
  // This will create a single gallery from all elements that have class "gallery-item"
  $('.insta_gallery').magnificPopup({
      type: 'image',
      delegate: 'a',
      gallery: {
          enabled: true ,
      }
  });